const Assignment3B = artifacts.require("Assignment3B");

module.exports = async function (deployer, network, accounts) {
 await deployer.deploy(Assignment3B);
};
